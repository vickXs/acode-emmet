window.acode.setPlugin("acode_emmet", async (server, $page, { cacheFile, storage }) => {
  class AcodeEmmet {
    async init() {
      this.editorManager = window.editorManager;
      if (!this.editorManager) return;

      this.editor = this.editorManager.editor;
      
      // Register a custom language tools completer for Ace Editor
      if (window.ace && window.ace.require) {
        try {
          const langTools = window.ace.require("ace/ext/language_tools");
          
          const emmetCompleter = {
            getCompletions: (editor, session, pos, prefix, callback) => {
              // Only trigger if the user has typed something valid
              if (!prefix || prefix.length < 1) {
                return callback(null, []);
              }

              // Check if it matches an abbreviation pattern
              const expanded = this.parseEmmet(prefix);
              if (!expanded) {
                return callback(null, []);
              }

              // Return the suggestion to the popup list
              callback(null, [{
                caption: prefix,
                value: expanded, // What gets inserted when selected
                meta: "Emmet",
                score: 1000 // High score to keep it near the top
              }]);
            }
          };

          langTools.addCompleter(emmetCompleter);
        } catch (e) {
          console.error("Failed to load Ace language tools for Emmet", e);
        }
      }

      window.toast("Emmet autocomplete active!");
    }

    parseEmmet(abbr) {
      // 1. Boilerplate / Doctype shortcut
      if (abbr === "html:5" || abbr === "!") {
        return `<!DOCTYPE html>\n<html lang="en">\n<head>\n\t<meta charset="UTF-8">\n\t<meta name="viewport" content="width=device-width, initial-scale=1.0">\n\t<title>Document</title>\n</head>\n<body>\n\t\n</body>\n</html>`;
      }

      // 2. Class shorthand (e.g., div.container -> <div class="container"></div>)
      const classMatch = abbr.match(/^([a-zA-Z0-9]*)\.([\w\-]+)$/);
      if (classMatch) {
        const tag = classMatch[1] || "div";
        const cls = classMatch[2];
        return `<${tag} class="${cls}"></${tag}>`;
      }

      // 3. ID shorthand (e.g., div#main -> <div id="main"></div>)
      const idMatch = abbr.match(/^([a-zA-Z0-9]*)\#([\w\-]+)$/);
      if (idMatch) {
        const tag = idMatch[1] || "div";
        const id = idMatch[2];
        return `<${tag} id="${id}"></${tag}>`;
      }

      // 4. Basic tag wrapping (e.g., div, p, span, a)
      if (/^[a-zA-Z]+$/.test(abbr)) {
        return `<${abbr}></${abbr}>`;
      }

      return null;
    }

    async destroy() {
      // Cleanup if needed
    }
  }

  const emmetPlugin = new AcodeEmmet();
  emmetPlugin.init();
});
