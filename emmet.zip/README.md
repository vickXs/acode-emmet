# Emmet for Acode

Fast HTML and CSS abbreviation expansion for the Acode mobile editor. Type abbreviations like `div.container` or `html:5` and instantly expand them.

---

## Table of Contents
- [Features](#features)
- [Installation](#installation)
- [How to Use](#how-to-use)
- [License](#license)

---

## ✨ Features

* **Lightning Fast Expansion:** Expand complex HTML structures instantly.
* **Boilerplate Shortcuts:** Type `!` or `html:5` for a complete HTML5 document skeleton.
* **Class & ID Shorthands:** Quickly build elements like `div#main` or `p.text-center`.

---

## 📥 Installation

1. Download the plugin.
2. Reload Acode

---

## 🚀 How to Use

1. Open any HTML file in Acode.
2. Type an abbreviation (e.g., `ul.menu>li*3`).
3. Use the autocomplete suggestion list or press **Tab** or **CTRL-E** to expand.

---

## 📄 License

This project is licensed under the [MIT License](LICENSE).
